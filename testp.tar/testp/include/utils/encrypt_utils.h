#ifndef ENCRYPT_UTILS_H
#define ENCRYPT_UTILS_H

extern void xor_decrypt(char* s);

#endif // ENCRYPT_UTILS_H
